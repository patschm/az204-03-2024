﻿namespace MSALDemo;

public class ResponseToken
{
    public string? Token { get; set; }
    public string? RefreshToken { get; set; }
}
