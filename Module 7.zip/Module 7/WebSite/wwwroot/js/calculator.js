﻿export async function add(a, b) {
    return a + b;
}
export async function subtract(a, b) {
    return a - b;
}
