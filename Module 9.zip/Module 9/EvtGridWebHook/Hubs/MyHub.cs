﻿using Microsoft.AspNetCore.SignalR;

namespace EvtGridWebHook.Hubs;

public class MyHub : Hub
{
}
