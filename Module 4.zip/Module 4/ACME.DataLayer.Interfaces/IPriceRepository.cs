﻿using ACME.DataLayer.Entities;

namespace ACME.DataLayer.Interfaces;

public interface IPriceRepository : IRepository<Price>
{
}
