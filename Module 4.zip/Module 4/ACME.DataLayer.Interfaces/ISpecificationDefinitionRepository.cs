﻿using ACME.DataLayer.Entities;

namespace ACME.DataLayer.Interfaces;

public interface ISpecificationDefinitionRepository : IRepository<SpecificationDefinition>
{
}
