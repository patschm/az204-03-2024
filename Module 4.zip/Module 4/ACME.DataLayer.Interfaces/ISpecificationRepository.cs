﻿using ACME.DataLayer.Entities;

namespace ACME.DataLayer.Interfaces;

public interface ISpecificationRepository : IRepository<Specification>
{
}
