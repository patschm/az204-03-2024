﻿namespace ACME.DataLayer.Entities;

public class Entity
{
    public long Id { get; set; }
    public byte[]? Timestamp { get; set; }
}
