﻿namespace ACME.DataLayer.Entities;

public enum ReviewType
{
    Generic,
    Expert,
    Consumer,
    Web
}