namespace Entities;

public class Brand
{
    public int ID { get; set; }
    public string? Name { get; set; }
    public string? Website { get; set; }
}