using Entities;

namespace Interfaces
{
    public interface IBrandRepository: IRepository<Brand>
    {
        
    }
}