﻿using Entities;

namespace Interfaces
{
    public interface IProductRepository : IRepository<Product>
    {
        
    }
}
